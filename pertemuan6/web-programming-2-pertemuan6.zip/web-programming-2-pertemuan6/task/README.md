# Task - pertemuan6

### Buatlah implementasi CRUD sederhana dari table:
 - Vendor
 - Pembelian
 - Kartu
 
 Diperbolehkan untuk belajar bersama
 Dilarang copy paste dan melakukan plagiarism